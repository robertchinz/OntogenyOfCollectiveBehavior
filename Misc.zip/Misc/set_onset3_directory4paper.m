function set_onset3_directory4paper(data_outputdir)

figure_outputdir = mfilename('fullpath');
figure_outputdir = figure_outputdir(1:strfind(figure_outputdir,'figures_Paper')+13);

if exist(data_outputdir,'dir') ~= 7 
    mkdir(data_outputdir)
end

% if exist(figure_outputdir,'dir') ~= 7 
%     error('Path for input data not found!')
% end

if ~strcmp(figure_outputdir(end),'\')
    figure_outputdir = [figure_outputdir '\'];
end

if ~strcmp(data_outputdir(end),'\')
    data_outputdir = [data_outputdir '\'];
end

setenv('ONSET3_PATH',data_outputdir)
setenv('SYNCPLICITY_PATH',figure_outputdir)

% Add input data and scripts to Matlab path
addpath(genpath(figure_outputdir))