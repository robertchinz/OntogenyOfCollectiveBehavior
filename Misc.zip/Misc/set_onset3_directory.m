function set_onset3_directory
data_outputdir = getenv('ONSET3_PATH');
figure_outputdir = getenv('SYNCPLICITY_PATH');

disp(['Figures will be saved to ' figure_outputdir])
disp(['Data will be saved to ' data_outputdir '. Around 302 GB!!!' ])


% if strcmpi(getenv('COMPUTERNAME'),'INRC-GPOLA-08') % Raul
%     onset3_directory = 'Z:\Onset3\';
%     syncp_onset3_directory = 'E:\usuarios\Robert\Documents\Syncplicity Folders\';
% elseif strcmpi(getenv('COMPUTERNAME'),'INRC-GPOLA-03')
%     onset3_directory = 'Z:\Onset3\';
%     syncp_onset3_directory = 'C:\Users\Usuario\Syncplicity Folders\';
% elseif strcmpi(getenv('COMPUTERNAME'),'INRC-GPOLA-02') % Alfonso
%     dos('subst Z: G:\onset3_results')
%     onset3_directory = 'Z:\Onset3\';
%     syncp_onset3_directory = 'G:\Users\Laboratorio\Syncplicity Folders\';
% elseif strcmpi(getenv('COMPUTERNAME'),'INRC-GPOLA-99') % Laptop
%     dos('subst Z: D:\onset3_results')
%     onset3_directory = 'Z:\Onset3\';
%     syncp_onset3_directory = 'C:\Users\hinz\Syncplicity Folders\';
% elseif strcmpi(getenv('COMPUTERNAME'),'USER-PC') % Julian Champalimaud
%     dos('subst Z: E:\onset3_results')
%     onset3_directory = 'Z:\Onset3\';
%     syncp_onset3_directory = 'C:\Users\User\Syncplicity Folders\';
% elseif strcmpi(getenv('COMPUTERNAME'),'ROBERT-CCU')
%     onset3_directory = 'Z:\Onset3\';
%     syncp_onset3_directory = 'C:\Users\Robert\Syncplicity Folders\';
% end
